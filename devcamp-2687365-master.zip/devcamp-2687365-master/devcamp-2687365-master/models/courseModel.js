const mongoose = require('mongoose')

//Definie un modelo que solo trabaje con mongo
const courseSchema = new mongoose.Schema({
    title : {
        type:String,
        unique: true,
        required: [true, "Titulo repetido"],
        minlenght: [10, "Limite de caracteres"],
        maxlenght: [30, "Limite de caracteres"]
    },
    description : {
        type:String,
        required: ["Descripcion necesaria"],
        minlenght: [10, "Limite de caracteres"]
    },
    weeks : {
        type:Number,
        required: ["Establece las semanas necesarias    "],
        max:[9,"Solo se aceptan 9 semanas para el curso"]
    },
    tuition : {
        type:Number,
        required: ["El curso debe tener un precio asignado"]
    },
    minimumSkills : {
        type:[String],
        required:["Debe asignar una habilidad"],
        enum:[ "Beginner" , "Intermediate" , "Advanced", "Expert" ]
    },
    createdAt : {
        type: Date,
        required: [true, "Debe ingresarse fecha de creación"]
    }
})

const Course = mongoose.model("Course",courseSchema)

module.exports = Course
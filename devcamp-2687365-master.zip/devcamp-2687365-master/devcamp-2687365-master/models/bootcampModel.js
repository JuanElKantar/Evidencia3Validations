const mongoose = require('mongoose')

//Definie un modelo que solo trabaje con mongo
const bootcampSchema = new mongoose.Schema({
    name: {
        type:String,
        unique: true,
        required:[true,"Se requiere nombre del bootcamp"],
        maxlength:[20,"Límite de caracteres"]
    },
    phone: {
        type:Number,
        unique: true,
        required:[true,"Celular repetido"],
        max:[999999999,"Límite de caracteres"]
    },
    address: {
        type:String,
        required:[true,"Dirección obligatoria"],
    },
    topics: {
        type:[String],
        enum:["Inteligencia","Backend","Python"]
    },
    averageRating: Number,
    createdAt: {
        type:Date,
        default:Date.now
    }
})

const Bootcamp = mongoose.model("Bootcamp",bootcampSchema)

module.exports = Bootcamp